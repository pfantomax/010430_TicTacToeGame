#ifndef TICTACTOEGAME_H
#define TICTACTOEGAME_H

#include <QWidget>
#include <QPushButton>
#include <QGridLayout>
#include <QMessageBox>

class TicTacToeGame : public QWidget {
    Q_OBJECT

public:
    TicTacToeGame(QWidget *parent = nullptr);

private slots:
    void handleButtonClick(int row, int col);
    void startNewGame();
    void togglePlayer();

private:
    enum class Player { None, X, O };

    QGridLayout *gridLayout;
    QVector<QVector<Player>> board;
    Player currentPlayer;
    bool againstComputer;

    void initializeBoard();
    void checkForWinner();
    void switchPlayer();
    void showWinner(Player winner);
    void resetGame();
    void makeComputerMove();
};

#endif // TICTACTOEGAME_H
