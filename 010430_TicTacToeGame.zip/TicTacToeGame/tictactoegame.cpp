#include "TicTacToeGame.h"
#include <QRandomGenerator>

TicTacToeGame::TicTacToeGame(QWidget *parent)
    : QWidget(parent), currentPlayer(Player::X), againstComputer(false) {
    gridLayout = new QGridLayout(this);
    initializeBoard();

    QPushButton *newGameButton = new QPushButton("Нова гра", this);
    connect(newGameButton, &QPushButton::clicked, this, &TicTacToeGame::startNewGame);

    QPushButton *togglePlayerButton = new QPushButton("Змінити гравця", this);
    connect(togglePlayerButton, &QPushButton::clicked, this, &TicTacToeGame::togglePlayer);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addLayout(gridLayout);
    layout->addWidget(newGameButton);
    layout->addWidget(togglePlayerButton);

    setLayout(layout);
}

void TicTacToeGame::initializeBoard() {
    board = QVector<QVector<Player>>(3, QVector<Player>(3, Player::None));

    for (int row = 0; row < 3; ++row) {
        for (int col = 0; col < 3; ++col) {
            QPushButton *button = new QPushButton(this);
            button->setFixedSize(100, 100);
            button->setFont(QFont("Arial", 20));
            connect(button, &QPushButton::clicked, this, [this, row, col]() { handleButtonClick(row, col); });

            gridLayout->addWidget(button, row, col);
        }
    }
}

void TicTacToeGame::handleButtonClick(int row, int col) {
    if (board[row][col] == Player::None) {
        board[row][col] = currentPlayer;
        QPushButton *button = qobject_cast<QPushButton*>(gridLayout->itemAtPosition(row, col)->widget());
        button->setText(currentPlayer == Player::X ? "X" : "O");

        checkForWinner();
        switchPlayer();
        makeComputerMove();
    }
}

void TicTacToeGame::makeComputerMove() {
    if (againstComputer && currentPlayer == Player::O) {
        for (int row = 0; row < 3; ++row) {
            for (int col = 0; col < 3; ++col) {
                if (board[row][col] == Player::None) {
                    board[row][col] = Player::O;
                    QPushButton *button = qobject_cast<QPushButton*>(gridLayout->itemAtPosition(row, col)->widget());
                    button->setText("O");

                    checkForWinner();
                    switchPlayer();

                    return;
                }
            }
        }
    }
}

void TicTacToeGame::checkForWinner() {
    bool isFull = true;

    for (int i = 0; i < 3; ++i) {
        if (board[i][0] != Player::None && board[i][0] == board[i][1] && board[i][1] == board[i][2]) {
            showWinner(board[i][0]);
            return;
        }

        if (board[0][i] != Player::None && board[0][i] == board[1][i] && board[1][i] == board[2][i]) {
            showWinner(board[0][i]);
            return;
        }

        for (int j = 0; j < 3; ++j) {
            if (board[i][j] == Player::None) {
                isFull = false;
            }
        }
    }

    if (board[0][0] != Player::None && board[0][0] == board[1][1] && board[1][1] == board[2][2]) {
        showWinner(board[0][0]);
        return;
    }

    if (board[0][2] != Player::None && board[0][2] == board[1][1] && board[1][1] == board[2][0]) {
        showWinner(board[0][2]);
        return;
    }

    if (isFull) {
        showWinner(Player::None);
    }
}

void TicTacToeGame::switchPlayer() {
    currentPlayer = (currentPlayer == Player::X) ? Player::O : Player::X;
}

void TicTacToeGame::showWinner(Player winner) {
    QString message;

    if (winner == Player::None) {
        message = "Гра закінчилася нічиєю!";
    } else {
        message = (winner == Player::X) ? "Гравець X виграв!" : "Гравець O виграв!";
    }

    QMessageBox::information(this, "Кінець гри", message);
    resetGame();
}

void TicTacToeGame::resetGame() {
    for (int row = 0; row < 3; ++row) {
        for (int col = 0; col < 3; ++col) {
            board[row][col] = Player::None;
            QPushButton *button = qobject_cast<QPushButton*>(gridLayout->itemAtPosition(row, col)->widget());
            button->setText("");
        }
    }

    currentPlayer = Player::X;
}

void TicTacToeGame::startNewGame() {
    resetGame();
}

void TicTacToeGame::togglePlayer() {
    againstComputer = !againstComputer;
    resetGame();
    if (againstComputer && currentPlayer == Player::O) {
        makeComputerMove();
    }
}
